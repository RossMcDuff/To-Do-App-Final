import React, { useState, useEffect, useRef } from "react";
import { View, StatusBar, FlatList } from "react-native";
import styled from "styled-components/native";
import AddInput from "./Components/AddInput";
import TodoList from "./Components/TodoList";
import * as Font from "expo-font";
import AppLoading from "expo-app-loading";
import Empty from "./Components/Empty";
import Header from "./Components/Header";
import AsyncStorage from '@react-native-async-storage/async-storage';
import * as Location from 'expo-location';

const getFonts = () =>
  Font.loadAsync({
    "poppins-regular": require("./assets/fonts/Poppins/Poppins-Regular.ttf"),
    "poppins-bold": require("./assets/fonts/Poppins/Poppins-Bold.ttf"),
  });

export default function App() {
  const [fontsLoaded, setFontsLoaded] = useState(false);
  const [data, setData] = useState([]);
  const mounted = useRef(false);

  const storeData = async (key, value) => {
    try {
      const jsonValue = JSON.stringify(value);
      await AsyncStorage.setItem(key, jsonValue);
    } catch (e) {
      console.log("storeData failure", e);
    }
  };

  const getData = async (key) => {
    try {
      const value = await AsyncStorage.getItem(key);
      if (value !== null) setData(JSON.parse(value));
    } catch (e) {
      console.log("getData failure", e);
      if (key === "tasks") setData([]);
    }
  };

  useEffect(() => {
    mounted.current = true;
    getData("tasks");
    return () => {
      mounted.current = false;
    };
  }, []);

  useEffect(() => {
    if (mounted.current) storeData("tasks", data);
  }, [data]);

  useEffect(() => {
    (async () => {
      let { status } = await Location.requestForegroundPermissionsAsync();
      if (status !== 'granted') {
        console.log('Permission to access location was denied');
      }
    })();
  }, []);

  const locate = async (key, taskList) => {
    let location = await Location.getCurrentPositionAsync({});
    const locatedTaskList = taskList.map(todo => (
      todo.key === key ? { ...todo, location } : todo
    ));
    setData(locatedTaskList);
  };

  const photoAttach = (key, uri) => {
    const updatedTasks = data.map(todo => (
      todo.key === key ? { ...todo, photoUri: "photo-" + key } : todo
    ));
    storeData("photo-" + key, uri);
    setData(updatedTasks);
  };

  const submitHandler = (value) => {
    const key = Math.random().toString();
    const newTask = { value, key };
    const newList = [newTask, ...data];
    setData(newList);
    locate(key, newList);
  };

  const deleteItem = (key) => {
    setData(data.filter(todo => todo.key !== key));
  };

  const updateItem = (key, newValue) => {
    const updatedList = data.map(todo =>
      todo.key === key ? { ...todo, value: newValue } : todo
    );
    setData(updatedList);
  };

  if (!fontsLoaded) {
    return (
      <AppLoading
        startAsync={getFonts}
        onFinish={() => setFontsLoaded(true)}
        onError={console.warn}
      />
    );
  }

  return (
    <Container>
      <StatusBar barStyle="light-content" backgroundColor="midnightblue" />
      <ContentWrapper>
        <FlatList
          data={data}
          ListHeaderComponent={() => <Header />}
          ListEmptyComponent={() => <Empty />}
          keyExtractor={(item) => item.key}
          renderItem={({ item }) => (
            <TodoList
              item={item}
              deleteItem={deleteItem}
              photoAttach={photoAttach}
              updateItem={updateItem}
            />
          )}
        />
      </ContentWrapper>
      <InputWrapper>
        <AddInput submitHandler={submitHandler} />
      </InputWrapper>
    </Container>
  );
}

const Container = styled.View`
  flex: 1;
  background-color: #1a1a40;
`;

const ContentWrapper = styled.View`
  flex: 1;
  padding: 20px;
`;

const InputWrapper = styled.View`
  padding: 10px 20px;
  background-color: #12122d;
  border-top-width: 1px;
  border-color: #303060;
`;
