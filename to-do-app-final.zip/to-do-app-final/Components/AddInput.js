import React, { useState } from "react";
import styled from "styled-components/native";
import { AntDesign, Feather } from "@expo/vector-icons";

export default function AddInput({ submitHandler }) {
  const [value, setValue] = useState("");

  const handleAdd = () => {
    if (value.trim()) {
      submitHandler(value.trim());
      setValue(""); // Clear after submit
    }
  };

  return (
    <ComponentContainer>
      <InputWrapper>
        <Feather name="edit-2" size={20} color="#999" style={{ marginLeft: 10 }} />
        <StyledInput
          placeholder="Add a task..."
          placeholderTextColor="#aaa"
          onChangeText={setValue}
          value={value}
        />
      </InputWrapper>
      <SubmitButton onPress={handleAdd}>
        <AntDesign name="plus" size={24} color="white" />
      </SubmitButton>
    </ComponentContainer>
  );
}

// ------------------ STYLED COMPONENTS ------------------

const ComponentContainer = styled.View`
  flex-direction: row;
  align-items: center;
  justify-content: center;
  margin-top: 10px;
`;

const InputWrapper = styled.View`
  flex-direction: row;
  align-items: center;
  background-color: #fff;
  border-radius: 12px;
  width: 80%;
  padding: 10px;
  elevation: 3;
  shadow-color: #000;
  shadow-opacity: 0.05;
  shadow-radius: 4px;
`;

const StyledInput = styled.TextInput`
  font-family: poppins-regular;
  font-size: 16px;
  flex: 1;
  padding-left: 10px;
  color: #333;
`;

const SubmitButton = styled.TouchableOpacity`
  background-color: midnightblue;
  width: 50px;
  height: 50px;
  border-radius: 25px;
  justify-content: center;
  align-items: center;
  margin-left: 10px;
  elevation: 3;
  shadow-color: #000;
  shadow-opacity: 0.1;
  shadow-radius: 5px;
`;
