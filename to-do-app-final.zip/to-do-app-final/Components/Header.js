import React from "react";
import styled from "styled-components/native";
import { Feather } from "@expo/vector-icons"; // Make sure it's installed
import moment from "moment";

export default function Header() {
  const today = moment().format("dddd, MMMM Do");

  return (
    <HeaderWrapper>
      <LeftSection>
        <Feather name="calendar" size={26} color="white" />
        <HeaderText>To Do List</HeaderText>
      </LeftSection>
      <HeaderDate>{today}</HeaderDate>
    </HeaderWrapper>
  );
}

const HeaderWrapper = styled.View`
  height: 100px;
  padding: 20px;
  background-color: #1e1e3f;
  flex-direction: row;
  justify-content: space-between;
  align-items: center;
  border-bottom-width: 1px;
  border-color: #333;
`;

const LeftSection = styled.View`
  flex-direction: row;
  align-items: center;
`;

const HeaderText = styled.Text`
  color: white;
  font-family: poppins-bold;
  font-size: 28px;
  margin-left: 10px;
`;

const HeaderDate = styled.Text`
  color: #aaa;
  font-family: poppins-regular;
  font-size: 16px;
`;
