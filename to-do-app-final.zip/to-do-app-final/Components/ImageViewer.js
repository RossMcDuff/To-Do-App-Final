import React, { useState, useEffect } from 'react';
import { StyleSheet, Text, View, TouchableOpacity, Image } from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { AntDesign } from '@expo/vector-icons';

export default function ImageViewer({ item, goBack }) {
  const [retrievedPhotoUri, setRetrievedPhotoUri] = useState("");

  const getImage = async (key) => {
    try {
      const value = await AsyncStorage.getItem(key);
      if (value !== null) {
        setRetrievedPhotoUri(JSON.parse(value));
      }
    } catch (e) {
      console.log("getImage failure", e);
    }
  };

  useEffect(() => {
    getImage(item.photoUri);
  }, []);

  return (
    <View style={styles.container}>
      {/* Close Button */}
      <TouchableOpacity style={styles.closeButton} onPress={goBack}>
        <AntDesign name="closecircle" size={32} color="white" />
      </TouchableOpacity>

      {retrievedPhotoUri ? (
        <Image source={{ uri: retrievedPhotoUri }} style={styles.container} />
      ) : (
        <Text>Still loading from {item.photoUri}</Text>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  closeButton: {
    position: 'absolute',
    top: 40,
    left: 20,
    zIndex: 2,
  },
});
