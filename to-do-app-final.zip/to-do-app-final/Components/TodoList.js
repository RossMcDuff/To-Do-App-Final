import React, { useState } from 'react';
import { View, Text, Modal, Pressable, TextInput } from 'react-native';
import { Entypo, MaterialIcons } from '@expo/vector-icons';
import styled from 'styled-components/native';
import CameraImage from './CameraImage';
import ImageViewer from './ImageViewer';

export default function TodoList({ item, deleteItem, photoAttach, updateItem }) {
  const [modalVisibleCameraImage, setModalVisibleCameraImage] = useState(false);
  const [modalVisibleImageViewer, setModalVisibleImageViewer] = useState(false);
  const [modalVisibleEdit, setModalVisibleEdit] = useState(false);
  const [updatedText, setUpdatedText] = useState(item.value);

  return (
    <ComponentContainer>
      <ListCard>
        <LeftSection>
          <Entypo name="circle" size={20} color="midnightblue" />
          <TextContent>
            <TaskText>{item.value}</TaskText>
            <LocationText>
              {item.location
                ? `📍 ${item.location.coords.latitude.toFixed(3)}, ${item.location.coords.longitude.toFixed(3)}`
                : 'Not located'}
            </LocationText>
          </TextContent>
        </LeftSection>

        <IconsRow>
          <MaterialIcons name="edit" size={22} color="midnightblue" onPress={() => setModalVisibleEdit(true)} />
          <MaterialIcons name="photo" size={22} color="midnightblue" onPress={() => setModalVisibleImageViewer(true)} />
          <MaterialIcons name="photo-camera" size={22} color="midnightblue" onPress={() => setModalVisibleCameraImage(true)} />
          <MaterialIcons name="delete" size={22} color="crimson" onPress={() => deleteItem(item.key)} />
        </IconsRow>
      </ListCard>

      {/* Edit Modal */}
      <Modal transparent={true} visible={modalVisibleEdit} onRequestClose={() => setModalVisibleEdit(false)}>
        <ModalOverlay>
          <ModalBox>
            <ModalTitle>Edit Task</ModalTitle>
            <StyledTextInput
              value={updatedText}
              onChangeText={setUpdatedText}
              placeholder="Update your task"
              placeholderTextColor="#888"
            />
            <SaveButton onPress={() => {
              updateItem(item.key, updatedText);
              setModalVisibleEdit(false);
            }}>
              <SaveText>Save</SaveText>
            </SaveButton>
          </ModalBox>
        </ModalOverlay>
      </Modal>

      {/* Camera Modal */}
      <Modal transparent={false} visible={modalVisibleCameraImage} onRequestClose={() => setModalVisibleCameraImage(false)}>
        <CameraImage 
          photoAttach={photoAttach} 
          item={item} 
          goBack={() => setModalVisibleCameraImage(false)} 
        />
      </Modal>

      {/* Viewer Modal */}
      <Modal transparent={false} visible={modalVisibleImageViewer} onRequestClose={() => setModalVisibleImageViewer(false)}>
        <ImageViewer 
          item={item} 
          goBack={() => setModalVisibleImageViewer(false)} 
        />
      </Modal>
    </ComponentContainer>
  );
}

// ------------------ STYLED COMPONENTS ------------------

const ComponentContainer = styled.View`
  align-items: center;
  margin-bottom: 20px;
`;

const ListCard = styled.View`
  width: 90%;
  padding: 15px;
  background-color: #f7f7fc;
  border-radius: 12px;
  shadow-color: #000;
  shadow-opacity: 0.1;
  shadow-radius: 6px;
  elevation: 3;
`;

const LeftSection = styled.View`
  flex-direction: row;
  align-items: flex-start;
`;

const TextContent = styled.View`
  margin-left: 10px;
  flex: 1;
`;

const TaskText = styled.Text`
  font-family: poppins-bold;
  font-size: 16px;
  color: #333;
`;

const LocationText = styled.Text`
  font-family: poppins-regular;
  font-size: 13px;
  color: #666;
  margin-top: 5px;
`;

const IconsRow = styled.View`
  flex-direction: row;
  justify-content: flex-end;
  margin-top: 15px;
`;

const ModalOverlay = styled.View`
  flex: 1;
  background-color: rgba(0,0,0,0.6);
  justify-content: center;
  align-items: center;
`;

const ModalBox = styled.View`
  width: 85%;
  background-color: white;
  padding: 20px;
  border-radius: 10px;
  elevation: 5;
`;

const ModalTitle = styled.Text`
  font-family: poppins-bold;
  font-size: 18px;
  margin-bottom: 15px;
`;

const StyledTextInput = styled.TextInput`
  border: 1px solid #ccc;
  padding: 10px;
  font-size: 16px;
  font-family: poppins-regular;
  margin-bottom: 20px;
  border-radius: 8px;
`;

const SaveButton = styled.TouchableOpacity`
  background-color: midnightblue;
  padding: 12px;
  align-items: center;
  border-radius: 8px;
`;

const SaveText = styled.Text`
  color: white;
  font-size: 16px;
  font-family: poppins-bold;
`;
